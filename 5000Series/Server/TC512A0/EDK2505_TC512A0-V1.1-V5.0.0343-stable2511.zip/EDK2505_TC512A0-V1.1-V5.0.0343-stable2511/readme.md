### OsTools

OsTools系统下可以更新固件和读取固件，使用方法如下：

Update the Firmware from file:

```
sudo ./OsTools spi -u -f LS3A50007A.fd
```

Dump the current Firmware to file:

```
sudo ./OsTools spi -d -f LS3A50007A.dump.fd
```

